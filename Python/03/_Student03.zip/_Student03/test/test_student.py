
def test_dodaj_ocjenu(prazan_student):

    prazan_student.dodaj_ocjenu("OET", 6)  # act = pokreni

    assert prazan_student.ocjene == {"OET": 6}  # assert - provjeri


def test_get_ocjena(student_sa_jednom_ocjenom):
    assert student_sa_jednom_ocjenom.get_ocjena("ORT") == 7  # act = pokreni + assert - provjeri


def test_izmjeni_ocjenu(student_sa_rtos_ocjenom):
    student_sa_rtos_ocjenom.izmjeni_ocjenu("RTOS", 6)  # act = pokreni
    assert student_sa_rtos_ocjenom.ocjene == {"RTOS": 6}  # assert - provjeri



def test_izlistaj_ocjene(student_za_izlistavanje):

    assert student_za_izlistavanje.izlistaj_ocjene() == ("ORT: 7\n"
                                                         "RTOS: 9\n"
                                                         "OET: 6")  # act = pokreni + assert - provjeri

def test_prosjek(student_za_prosjek):
    assert student_za_prosjek.prosjek() == 8  # act = pokreni + assert - provjeri