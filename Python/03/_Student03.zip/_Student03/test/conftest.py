import pytest
from main import Student

@pytest.fixture
def prazan_student():
    student = Student()  # arrange = postavi
    return student

@pytest.fixture
def student_sa_jednom_ocjenom():
    student = Student()  # arrange = postavi
    student.dodaj_ocjenu("ORT", 7)  # arrange = postavi
    return student

@pytest.fixture
def student_sa_rtos_ocjenom():
    student = Student()  # arrange = postavi
    student.dodaj_ocjenu("RTOS", 9)  # arrange = postavi
    return student

@pytest.fixture
def student_za_izlistavanje():
    student = Student()  # arrange = postavi
    student.dodaj_ocjenu("ORT", 7)  # arrange = postavi
    student.dodaj_ocjenu("RTOS", 9)  # arrange = postavi
    student.dodaj_ocjenu("OET", 6)  # arrange = postavi
    return student

@pytest.fixture
def student_za_prosjek():
    student = Student()  # arrange = postavi
    student.dodaj_ocjenu("ORT", 7)  # arrange = postavi
    student.dodaj_ocjenu("RTOS", 9)  # arrange = postavi
    student.dodaj_ocjenu("OET", 8)  # arrange = postavi
    return student
