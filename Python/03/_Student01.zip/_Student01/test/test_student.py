from main import Student


def test_dodaj_ocjenu():
    student = Student()  # arrange = postavi

    student.dodaj_ocjenu("OET", 6)  # act = pokreni

    assert student.ocjene == {"OET": 6}  # assert - provjeri


def test_get_ocjena():
    student = Student()  # arrange = postavi
    student.dodaj_ocjenu("ORT", 7)  # arrange = postavi

    assert student.get_ocjena("ORT") == 7  # act = pokreni + assert - provjeri


def test_izmjeni_ocjenu():
    student = Student()  # arrange = postavi
    student.dodaj_ocjenu("RTOS", 9)  # arrange = postavi

    student.izmjeni_ocjenu("RTOS", 6)  # act = pokreni

    assert student.ocjene == {"RTOS": 6}  # assert - provjeri



def test_izlistaj_ocjene():
    student = Student()  # arrange = postavi
    student.dodaj_ocjenu("ORT", 7)  # arrange = postavi
    student.dodaj_ocjenu("RTOS", 9)  # arrange = postavi
    student.dodaj_ocjenu("OET", 6)  # arrange = postavi

    assert student.izlistaj_ocjene() == ("ORT: 7\n"
                                         "RTOS: 9\n"
                                         "OET: 6")  # act = pokreni + assert - provjeri

def test_prosjek():
    student = Student()  # arrange = postavi
    student.dodaj_ocjenu("ORT", 7)  # arrange = postavi
    student.dodaj_ocjenu("RTOS", 9)  # arrange = postavi
    student.dodaj_ocjenu("OET", 8)  # arrange = postavi

    assert student.prosjek() == 8  # act = pokreni + assert - provjeri