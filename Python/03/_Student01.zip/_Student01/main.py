class Student:
    def __init__(self):
        self.ocjene = {}

    def dodaj_ocjenu(self, predmet, ocjena):
        if predmet not in self.ocjene:
            self.ocjene[predmet] = ocjena
            return True
        return False # ili exception

    def get_ocjena(self, predmet ):
        if predmet in self.ocjene:
            return self.ocjene[predmet]
        return None  # moze i exception

    def prosjek(self):
        if not self.ocjene: # prazan rjecnik je False
            return None
        return sum(self.ocjene.values())/len(self.ocjene)

    def izmjeni_ocjenu(self, predmet, ocjena):
        if predmet in self.ocjene:
            self.ocjene[predmet] = ocjena
            return True
        else:  # ovako je mozda citkije
            return False  # moze i exception

    def izlistaj_ocjene(self):
        if not self.ocjene: # prazan rjecnik je False
            return None
        return "\n".join(
            f"{predmet}: {self.ocjene[predmet]}" for predmet in self.ocjene
        )   # comprehenzija nad self.ocjene kojom stvaramo niz stringova "predment: ocjena"
            # zatim taj niz join-ujemo sa \n tako dobijemo cijelu listu u jednom stringu

    def izbrisi_ocjene(self):
        self.ocjene = {}
        return True

# Example usage:
if __name__ == "__main__":
    student = Student()
    print(student.dodaj_ocjenu("ORT", 9))
    print(student.dodaj_ocjenu("RTOS", 7))
    print(student.izmjeni_ocjenu("RTOS", 9))
    print(student.izlistaj_ocjene())
    print(student.prosjek())
